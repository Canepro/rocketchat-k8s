## Security Scan Results

- **Risk Level:** HIGH
- **Findings:**
  - Critical: 0
  - High: 1
  - Medium: 2
  - Low: 20

**Action Required:** Please review the security scan results and address critical vulnerabilities immediately.

**Scan Artifacts:**
- tfsec results: https://jenkins.canepro.me/job/security-validation-rocketchat-k8s/25/artifact/tfsec-results.json
- checkov results: https://jenkins.canepro.me/job/security-validation-rocketchat-k8s/25/artifact/checkov-results.json
- trivy results: https://jenkins.canepro.me/job/security-validation-rocketchat-k8s/25/artifact/trivy-*.json

**Next Steps:**
1. Review all critical findings
2. Create remediation PRs for each critical issue
3. Update security policies if needed

This issue was automatically created by Jenkins security validation pipeline.