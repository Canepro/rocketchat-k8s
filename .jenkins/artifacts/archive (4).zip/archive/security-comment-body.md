## New security scan results

- **Build:** https://jenkins.canepro.me/job/security-validation-rocketchat-k8s/25/
- **Findings:** Critical: 0 | High: 1 | Medium: 2 | Low: 20
- **Artifacts:** https://jenkins.canepro.me/job/security-validation-rocketchat-k8s/25/artifact/

(De-dupe enabled: this comment updates an existing open issue.)